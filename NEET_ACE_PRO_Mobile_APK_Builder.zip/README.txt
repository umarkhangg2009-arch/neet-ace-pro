NEET ACE PRO — Android Studio project

WHAT'S INCLUDED
- Native Android WebView shell (Kotlin)
- Coaching-style mobile UI
- Chapter syllabus maps for Physics, Chemistry, Botany, Zoology
- Chapterwise practice flow and difficulty selector
- PYQ workspace with year filters (content not yet populated with verified PYQs)
- Mock-test demo engine: timer, navigation, question palette, mark-for-review, submit and review
- NEET-style scoring (+4/-1/0)
- Performance analytics saved locally on the device

IMPORTANT CONTENT LIMITS
- Bundled questions are original illustrative demo questions, not claimed as official PYQs.
- The app maps many syllabus chapters, but most chapter banks are not populated yet.
- Mock mode currently uses the bundled demo bank; it is not a complete 180-question official-length paper.
- A verified question bank needs authentic source material and fact-checking/licensing before publication.

BUILD APK
1. Install Android Studio on a computer.
2. Open this folder (NeetAcePro) in Android Studio.
3. Install Android SDK Platform 35 if prompted and allow Gradle sync.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Find the APK under app/build/outputs/apk/debug/app-debug.apk.

This environment does not have Android SDK/Gradle installed, so it cannot compile/sign the APK here.
